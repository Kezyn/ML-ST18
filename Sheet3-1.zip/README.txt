Interpretator: python 3.6, required: weka, python-weka-wrapper3
Interpretator: python 2.7, required: weka, python-weka-wrapper

run the code via you terminal with:
>> python Sheet3-1_code.py -p "/path/to/dataset/file.arff" [-t NUMBER_OF_TREES]

