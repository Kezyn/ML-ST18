python 2.7

run the code via you terminal with:
>> python ./Sheet3-1.py

