from sklearn.ensemble import RandomForestClassifier
import random

def parseARFF(filepath):
    headers = []
    data = []
    for line in open(filepath):
        if line.startswith("%"):
            continue
        if line.startswith("@attribute"):
            headers.append(line.strip().split()[1])
        elif not line.startswith("@") and len(line.strip()) > 0:
            data.append(line.strip().split(','))
    return [headers] + data


def get_data(path, target):
   dataset = parseARFF(path)

   target_id = dataset[0].index(target)
   labels = list()
   samples = list()
   for row in dataset[1:]:
       current_row = list()
       current_label = row[target_id]
       for i, attr in enumerate(row):
           if i != target_id:
               current_row.append(attr)
       labels.append(current_label)
       samples.append(current_row)

   unique_attributes = set()
   for row in dataset:
       for attr in row:
           unique_attributes.add(attr)
   attributes_mapping = {attr: j for j, attr in {
       i: attr for i, attr in enumerate(list(sorted(set(unique_attributes))))
   }.items()}
   for i, sample in enumerate(samples):
       mod_sample = [attributes_mapping[attr] for attr in sample]
       samples[i] = mod_sample

   labels_mapping = {lb: j for j, lb in {i: lb for i, lb in enumerate(list(sorted(set(labels))))}.items()}
   labels = [labels_mapping[lb] for lb in labels]

   return samples, labels


def split_data(data, labels, test_size):
    data_train = []
    data_test = []
    labels_train = []
    labels_test = []

    indices = list(range(len(data)))
    random.shuffle(indices)
    num_test = int(round(len(indices) * test_size, 0))

    test_ids = indices[:num_test]
    for idx in test_ids:
        data_test.append(data[idx])
        labels_test.append(labels[idx])

    train_ids = indices[num_test:]
    for idx in train_ids:
        data_train.append(data[idx])
        labels_train.append(labels[idx])
    return data_train, data_test, labels_train, labels_test


def main():
    random.seed(42)

    path = 'data/car.arff'
    target = 'class'

    data, labels = get_data(path, target)

    test_size = 1.0 / 3

    data_train, data_test, labels_train, labels_test = split_data(data, labels, test_size)

    for num_trees in [1, 5, 10, 20, 30, 40, 50]:
        accuracy = list()
        for i in range(10):
            rf = RandomForestClassifier(n_estimators=num_trees, criterion='entropy', random_state = i, n_jobs = -1)
            rf.fit(data_train, labels_train)
            predicted = rf.predict(data_test)
            num_correct = sum([1.0 for y, gt in zip(predicted, labels_test) if y == gt])
            accuracy.append(num_correct / len(labels_test))
        acc_mean = 1.0 * sum(accuracy) / len(accuracy)
        acc_std = (sum((x - acc_mean) ** 2 for x in accuracy) / len(accuracy)) ** 0.5
        print('Maximum number of trees: {}\n'.format(num_trees))
        print('Accuracy (mean={:.4f}, std={:.4f}:\n{})'.format(
                acc_mean,
                acc_std,
                [float('{:.04f}'.format(acc)) for acc in accuracy]
            ))
        print('-' * 120)

if __name__ == '__main__':
    main()